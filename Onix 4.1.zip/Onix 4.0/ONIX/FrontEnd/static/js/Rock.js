document.addEventListener('DOMContentLoaded', function () {
    // Manejo de eventos al cargar la página
    const carritoModal = document.getElementById('carrito-modal');
    const carritoIcono = document.getElementById('carrito-icono');
    const cerrarCarritoBtn = document.getElementById('cerrar-carrito');
    const applyFiltersBtn = document.getElementById('apply-filters');

    // Función para mostrar/ocultar el modal del carrito
    function toggleCarritoModal(show) {
        carritoModal.style.display = show ? 'block' : 'none';
    }

    // Verificar si el carrito debe abrirse al cargar la página
    if (localStorage.getItem('abrirCarrito') === 'true') {
        toggleCarritoModal(true);
        localStorage.removeItem('abrirCarrito'); // Limpiar el estado
    }

    // Mostrar carrito
    carritoIcono.addEventListener('click', () => toggleCarritoModal(true));

    // Cerrar carrito
    cerrarCarritoBtn.addEventListener('click', () => toggleCarritoModal(false));

    // Función para aplicar filtros a los productos
    function aplicarFiltros() {
        const nameFilter = document.getElementById('name-filter').value.toLowerCase();
        const priceFilter = parseInt(document.getElementById('price-filter').value, 10);
        const products = document.querySelectorAll('.productos-box');

        products.forEach(product => {
            const productName = product.getAttribute('data-name').toLowerCase();
            const productPrice = parseInt(product.getAttribute('data-price'), 10);

            const mostrarProducto = (!nameFilter || productName === nameFilter) &&
                                    (!priceFilter || productPrice <= priceFilter);

            product.style.display = mostrarProducto ? 'block' : 'none';
        });
    }

    // Evento de filtrado de productos
    applyFiltersBtn.addEventListener('click', aplicarFiltros);

    // Función para actualizar la cantidad de productos y mostrar el carrito
    function actualizarCantidad(producto, cambio) {
        fetch('/actualizar_cantidad', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ producto, cambio })  // Enviar el nombre del producto y el cambio
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Guardar el estado para abrir el carrito después de la recarga
                localStorage.setItem('abrirCarrito', 'true');
                location.reload(); // Recarga la página para reflejar los cambios
            } else {
                console.error('Error al actualizar la cantidad:', data.error);
            }
        })
        .catch(error => console.error('Error al actualizar la cantidad:', error));
    }

    // Añadir eventos a botones de incrementar y disminuir cantidad
    document.querySelectorAll('.btn-menos, .btn-mas').forEach(button => {
        button.addEventListener('click', () => {
            const producto = button.getAttribute('data-producto');  // Obtener el nombre del producto
            const cambio = button.classList.contains('btn-menos') ? -1 : 1;
            actualizarCantidad(producto, cambio);  // Pasar el nombre del producto y el cambio
        });
    });
});

// Añadir evento para cerrar el carrito
document.getElementById('cerrar-carrito').addEventListener('click', function() {
    document.getElementById('carrito-modal').style.display = 'none';
});

// Añadir evento para el botón de pagar
document.getElementById('btn-pagar').addEventListener('click', function() {
    // Realizar una solicitud POST para crear la sesión de pago con Stripe
    fetch('/crear_checkout', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({}),  // Si es necesario enviar datos adicionales, añádelos aquí
    })
    .then(response => response.json())
    .then(data => {
        if (data.url) {
            // Redirigir a la URL de Stripe para completar el pago
            window.location.href = data.url;
        } else {
            alert('Error al iniciar el pago');
        }
    })
    .catch(error => {
        console.error('Error en la solicitud:', error);
    });
});