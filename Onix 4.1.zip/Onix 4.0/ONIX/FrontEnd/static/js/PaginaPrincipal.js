function toggleCategories() {
    const categoryList = document.getElementById("category-list");
    categoryList.classList.toggle("hidden");
}

