document.querySelectorAll('.btn-add-to-cart').forEach(button => {
    button.addEventListener('click', () => {
        const productoBox = button.closest('.producto');
        const productoData = {
            producto_id: productoBox.dataset.id,
            nombre: productoBox.dataset.name,
            precio_unitario: parseInt(productoBox.dataset.price),
            cantidad: 1
        };

        fetch('/agregar-al-carrito', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(productoData)
        }).then(response => response.json())
          .then(data => {
              if (data.success) {
                  alert('Producto agregado al carrito');
              }
          });
    });
});
