import os
import sys
from flask import Flask, render_template, url_for, redirect, request, jsonify, session, make_response
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from Backend.ValidarLogin import ValidarLogin
from conectar import conexion
import bcrypt
import stripe

app = Flask(__name__, template_folder='FrontEnd/templates', static_folder='FrontEnd/static')
app.secret_key = 'supersecretkey'  # Esta clave es necesaria para las sesiones

Onix = conexion()

stripe.api_key = "sk_test_51PUCDVLFucmSagV6Tix5Ci8zIS0DOXWC4lUux7ZUe5rBwWRdJd9MlJ377w0KApqQ7LEmJUM8J4B0k8b193428aCu00y35a9jJJ"

# Configuración de las rutas de plantillas y estática
template_dir = os.path.join(os.path.dirname(__file__), '..', 'FrontEnd', 'templates')
static_dir = os.path.join(os.path.dirname(__file__), '..', 'FrontEnd', 'static')

app.template_folder = template_dir
app.static_folder = static_dir

@app.route('/')
def prueba():
    return render_template('Prueba.html')

@app.route('/log')
def log():
    return render_template('login.html')

@app.route('/catalogo')
def catalogo():
    correo = session.get('correo')  # Obtener correo de la sesión
    
    if correo:
        # Si el usuario está autenticado, obtener la información del usuario de la base de datos
        usuario = Onix.Usuarios.find_one({"correo": correo})
        nombre_usuario = usuario["nombre"] if usuario else None
        carrito = usuario.get('carrito', [])  # Obtener el carrito del usuario

        # Calcular el total del carrito
        total_carrito = sum(item['precio'] * item['cantidad'] for item in carrito)
        
        # Renderizar la plantilla Catalogo.html y pasar la información del usuario y el carrito
        return render_template('Catalogo.html', usuario_nombre=nombre_usuario, carrito=carrito, total_carrito=total_carrito)
    
    # Si no hay correo en la sesión (usuario no autenticado), redirigir a la página de login
    return redirect(url_for('log'))

@app.route('/rock')
def rock():
    correo = session.get('correo')  # Obtener correo de la sesión
    
    if correo:
        usuario = Onix.Usuarios.find_one({"correo": correo})
        nombre_usuario = usuario["nombre"] if usuario else None
        carrito = usuario.get('carrito', [])  # Obtén el carrito del usuario

        # Calcular el total del carrito
        total_carrito = sum(item['precio'] * item['cantidad'] for item in carrito)

        return render_template('Rock.html', usuario_nombre=nombre_usuario, carrito=carrito, total_carrito=total_carrito)
    
    return render_template('Rock.html', usuario_nombre=None, carrito=[], total_carrito=0)

@app.route('/pop')
def pop():
    correo = session.get('correo')  # Obtener correo de la sesión
    
    if correo:
        usuario = Onix.Usuarios.find_one({"correo": correo})
        nombre_usuario = usuario["nombre"] if usuario else None
        carrito = usuario.get('carrito', [])  # Obtener el carrito del usuario

        # Calcular el total del carrito
        total_carrito = sum(item['precio'] * item['cantidad'] for item in carrito)
        
        return render_template('Pop.html', usuario_nombre=nombre_usuario, carrito=carrito, total_carrito=total_carrito)
    
    return render_template('Pop.html', usuario_nombre=None, carrito=[], total_carrito=0)

@app.route('/jazz')
def jazz():
    correo = session.get('correo')  # Obtener correo de la sesión
    
    if correo:
        usuario = Onix.Usuarios.find_one({"correo": correo})
        nombre_usuario = usuario["nombre"] if usuario else None
        carrito = usuario.get('carrito', [])  # Obtener el carrito del usuario

        # Calcular el total del carrito
        total_carrito = sum(item['precio'] * item['cantidad'] for item in carrito)
        
        return render_template('Jazz.html', usuario_nombre=nombre_usuario, carrito=carrito, total_carrito=total_carrito)
    
    return render_template('Jazz.html', usuario_nombre=None, carrito=[], total_carrito=0)

@app.route('/hiphop')
def hiphop():
    correo = session.get('correo')  # Obtener correo de la sesión
    
    if correo:
        usuario = Onix.Usuarios.find_one({"correo": correo})
        nombre_usuario = usuario["nombre"] if usuario else None
        carrito = usuario.get('carrito', [])  # Obtener el carrito del usuario

        # Calcular el total del carrito
        total_carrito = sum(item['precio'] * item['cantidad'] for item in carrito)
        
        return render_template('Hiphop.html', usuario_nombre=nombre_usuario, carrito=carrito, total_carrito=total_carrito)
    
    return render_template('Hiphop.html', usuario_nombre=None, carrito=[], total_carrito=0)

@app.route('/kpop')
def kpop():
    correo = session.get('correo')  # Obtener correo de la sesión
    
    if correo:
        usuario = Onix.Usuarios.find_one({"correo": correo})
        nombre_usuario = usuario["nombre"] if usuario else None
        carrito = usuario.get('carrito', [])  # Obtener el carrito del usuario

        # Calcular el total del carrito
        total_carrito = sum(item['precio'] * item['cantidad'] for item in carrito)
        
        return render_template('Kpop.html', usuario_nombre=nombre_usuario, carrito=carrito, total_carrito=total_carrito)
    
    return render_template('Kpop.html', usuario_nombre=None, carrito=[], total_carrito=0)

@app.route('/metal')
def metal():
    correo = session.get('correo')  # Obtener correo de la sesión
    
    if correo:
        usuario = Onix.Usuarios.find_one({"correo": correo})
        nombre_usuario = usuario["nombre"] if usuario else None
        carrito = usuario.get('carrito', [])  # Obtener el carrito del usuario

        # Calcular el total del carrito
        total_carrito = sum(item['precio'] * item['cantidad'] for item in carrito)
        
        return render_template('Metal.html', usuario_nombre=nombre_usuario, carrito=carrito, total_carrito=total_carrito)
    
    return render_template('Metal.html', usuario_nombre=None, carrito=[], total_carrito=0)

@app.route('/instrumentos')
def instrumentos():
    correo = session.get('correo')  # Obtener correo de la sesión
    
    if correo:
        usuario = Onix.Usuarios.find_one({"correo": correo})
        nombre_usuario = usuario["nombre"] if usuario else None
        carrito = usuario.get('carrito', [])  # Obtener el carrito del usuario

        # Calcular el total del carrito
        total_carrito = sum(item['precio'] * item['cantidad'] for item in carrito)
        
        return render_template('Instrumentos.html', usuario_nombre=nombre_usuario, carrito=carrito, total_carrito=total_carrito)
    
    return render_template('Instrumentos.html', usuario_nombre=None, carrito=[], total_carrito=0)

@app.route('/inicio')
def inicio():
    correo = session.get('correo')
    if correo:
        usuario = Onix.Usuarios.find_one({"correo": correo})
        nombre_usuario = usuario["nombre"] if usuario else None
        session['usuario_nombre'] = nombre_usuario  # Almacena el nombre en la sesión
    else:
        nombre_usuario = None

    return render_template('PaginaPrincipal.html', nombre_usuario=nombre_usuario)

@app.route('/registrar', methods=['GET', 'POST'])
def registrar():
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        correo = request.form.get('email')
        password = request.form.get('password')
        
        # Hashear la contraseña
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

        # Crear el documento de usuario con un carrito vacío
        usuario = {
            "nombre": nombre,
            "correo": correo,
            "password": hashed_password,
            "carrito": []  # El carrito está vacío al principio
        }

        # Insertar el nuevo usuario en la base de datos
        Onix.Usuarios.insert_one(usuario)

        # Redirigir a la página de login
        return redirect(url_for('log'))  

    return render_template('Registro.html')

@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        datos_login = request.form
        correo = datos_login.get('email')
        clave = datos_login.get('password')

        validador = ValidarLogin(correo, clave)

        if validador.validar():
            print("Login exitoso, sesión establecida con correo:", correo)
            session['correo'] = correo  # Almacenar correo en la sesión
            resp = make_response(redirect(url_for('inicio')))
            return resp
        else:
            return render_template('login.html', error='Correo o contraseña incorrectos')

@app.route('/logout')
def logout():
    session.pop('correo', None)
    session.pop('usuario_nombre', None)
    return redirect(url_for('log'))

@app.route('/agregar_al_carrito', methods=['POST'])
def agregar_al_carrito():
    if 'correo' in session:
        correo = session['correo']
        producto = request.form.get('producto')
        precio = float(request.form.get('precio'))
        redirect_url = request.form.get('redirect_url', '/')

        # Buscar el usuario en la base de datos
        usuario = Onix.Usuarios.find_one({"correo": correo})

        if usuario:
            carrito = usuario.get('carrito', [])
            
            # Verificar si el producto ya está en el carrito
            producto_existente = next((item for item in carrito if item['producto'] == producto), None)
            
            if producto_existente:
                # Si el producto ya está en el carrito, incrementar la cantidad
                producto_existente['cantidad'] += 1
            else:
                # Si el producto no está en el carrito, agregarlo con cantidad 1
                carrito.append({"producto": producto, "precio": precio, "cantidad": 1})
            
            # Actualizar el carrito en la base de datos
            Onix.Usuarios.update_one({"correo": correo}, {"$set": {"carrito": carrito}})

            # Redirigir al usuario a la URL de origen
            return redirect(redirect_url)
        else:
            # Si no se encuentra el usuario, redirigir a la página de login
            return redirect(url_for('log'))

    # Si el usuario no está autenticado, redirigir a la página de login
    return redirect(url_for('log'))


@app.route('/actualizar_cantidad', methods=['POST'])
def actualizar_cantidad():
    data = request.get_json()
    producto_nombre = data.get('producto')
    cambio = data.get('cambio')

    correo = session.get('correo')  # Suponiendo que el usuario está autenticado
    if correo:
        usuario = Onix.Usuarios.find_one({"correo": correo})
        if usuario:
            # Recorrer los productos en el carrito
            for item in usuario['carrito']:
                if item['producto'] == producto_nombre:
                    item['cantidad'] += cambio
                    if item['cantidad'] <= 0:
                        # Si la cantidad es 0 o negativa, eliminar el producto
                        usuario['carrito'].remove(item)
                        # Actualizar el carrito en la base de datos
                        Onix.Usuarios.update_one(
                            {"correo": correo},
                            {"$set": {"carrito": usuario['carrito']}}
                        )
                        return jsonify({"success": True, "message": f"El producto {producto_nombre} ha sido eliminado por cantidad 0."})
                    
                    # Si la cantidad es positiva, actualizar el carrito
                    Onix.Usuarios.update_one(
                        {"correo": correo},
                        {"$set": {"carrito": usuario['carrito']}}
                    )
                    return jsonify({"success": True, "message": f"Cantidad del producto {producto_nombre} actualizada."})

    return jsonify({"success": False, "error": "Producto no encontrado o usuario no autenticado"})
 
@app.route('/crear_checkout', methods=['POST'])
def crear_checkout():
    if 'correo' in session:
        correo = session['correo']
        usuario = Onix.Usuarios.find_one({"correo": correo})

        if usuario:
            carrito = usuario.get('carrito', [])

            # Crea una lista de productos para Stripe
            line_items = []
            for item in carrito:
                line_items.append({
                    'price_data': {
                        'currency': 'clp',
                        'product_data': {
                            'name': item['producto'],
                        },
                        'unit_amount': int(item['precio']),
                    },
                    'quantity': item['cantidad'],
                })

            # Crear una sesión de pago con Stripe
            session_stripe = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=line_items,
                mode='payment',
                success_url=url_for('exito', _external=True),  # Redirige a una página de éxito
                cancel_url=url_for('cancelar', _external=True),  # Redirige a una página de cancelación
            )

            # Devuelve la URL del checkout de Stripe para redirigir al usuario
            return jsonify({'url': session_stripe.url})

    return jsonify({'error': 'Usuario no autenticado'})

@app.route('/exito')
def exito():
    # Asegúrate de que el usuario esté autenticado
    if 'correo' in session:
        correo = session['correo']
        usuario = Onix.Usuarios.find_one({"correo": correo})

        if usuario:
            # Vaciar el carrito del usuario
            Onix.Usuarios.update_one(
                {"correo": correo},
                {"$set": {"carrito": []}}  # Deja el carrito vacío
            )
    
    return render_template('exito.html')  # O cualquier plantilla que desees para el éxito


@app.route('/cancelar')
def cancelar():
    return render_template('cancelar.html')



if __name__ == '__main__':
    app.run(debug=True)
